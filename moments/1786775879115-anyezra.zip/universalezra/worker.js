export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    const m = request.method;
    const headers = {
      "Access-Control-Allow-Origin": "https://anyezra.pages.dev",
      "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type"
    };
    if (m === "OPTIONS") return new Response(null, { headers });
    try {
      if (url.pathname === "/api/site-config") {
        if (m === "GET") {
          let config = await env.DB.get("dynamic_site_config", { type: "json" });
          if (!config) {
            config = {
              bgUrl: "https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=1920&q=80",
              title: "UNIVERSALEZRA",
              content: "",
              textColor: "#00ff00"
            }
          }
          return new Response(JSON.stringify(config), { headers, status: 200 })
        }
        if (m === "POST") {
          const body = await request.json();
          const ADMIN_PASSWORD = "ezraelvi21#";
          if (body.pass !== ADMIN_PASSWORD) {
            return new Response(JSON.stringify({ error: "" }), { status: 401, headers })
          }
          const newConfig = {
            bgUrl: body.bgUrl || "",
            title: body.title || "Untitled",
            content: body.content || "",
            textColor: body.textColor || "#00ff00"
          };
          await env.DB.put("dynamic_site_config", JSON.stringify(newConfig));
          return new Response(JSON.stringify({ success: true, config: newConfig }), { headers, status: 200 })
        }
      }
      return new Response(JSON.stringify({ error: "" }), { status: 404, headers })
} catch (err) { return new Response(JSON.stringify({ error: "Server Error: " + err.message }), { status: 500, headers })
}
}
}