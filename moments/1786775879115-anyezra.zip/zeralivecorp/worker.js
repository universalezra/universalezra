export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    const m = request.method;
    const headers = {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type, Authorization",
    }
    if (m === "OPTIONS") return new Response(null, { headers });    
    async function getUserFromToken(reqToken) {
        if (!reqToken) return null;
        let users = await env.DB.get("business_users", { type: "json" }) || {};
        for (let email in users) {
            if (users[email].token === reqToken) return { email, ...users[email] };
        }
        return null;
    }
    try {
      if (url.pathname === "/api/heartbeat" && m === "POST") {
        const body = await request.json();
        const bId = body.id || "Unknown";
        const now = Date.now();
        let onlineData = await env.DB.get("sys_online_users", { type: "json" }) || {};
        onlineData[bId] = now;
        let activeCount = 0;
        for (let key in onlineData) {
            if (now - onlineData[key] > 30000) delete onlineData[key];
            else activeCount++;
        }
        await env.DB.put("sys_online_users", JSON.stringify(onlineData));
        return new Response(JSON.stringify({ onlineCount: activeCount }), { headers, status: 200 });
      }

      if (url.pathname === "/api/public/announcements" && m === "GET") {
          let users = await env.DB.get("business_users", { type: "json" }) || {};
          let allPosts = [];
          for (let email in users) {
              let u = users[email];
              let wsData = await env.DB.get(`workspace_${u.folderId}`, { type: "json" }) || { posts: [] };
              if (wsData.posts) {
                  wsData.posts.forEach(p => {
                      allPosts.push({ ...p, author: email });
                  });
              }}
          allPosts.sort((a, b) => b.id - a.id);
          return new Response(JSON.stringify(allPosts.slice(0, 10)), { headers });
      }

      if (url.pathname === "/api/auth/local" && m === "POST") {
        const { action, email, pass } = await request.json();
        let users = await env.DB.get("business_users", { type: "json" }) || {}
        if (action === "signup") {
            if (users[email]) return new Response(JSON.stringify({ error: "User sudah terdaftar." }), { status: 400, headers });
            const token = crypto.randomUUID();
            const folderId = "FLD-" + Math.random().toString(36).substr(2, 8).toUpperCase();
            users[email] = { pass, token, folderId, type: "local", avatar: "" };
            await env.DB.put("business_users", JSON.stringify(users));
            await env.DB.put(`workspace_${folderId}`, JSON.stringify({ posts: [], files: [] }));
            return new Response(JSON.stringify({ success: true, token, user: { email, folderId, avatar: "" } }), { headers });
        }
        if (action === "login") {
            const user = users[email];
            if (!user || user.pass !== pass) return new Response(JSON.stringify({ error: "Kredensial salah." }), { status: 401, headers });
            return new Response(JSON.stringify({ success: true, token: user.token, user: { email, folderId: user.folderId, avatar: user.avatar || "" } }), { headers });
        }
      }

      if (url.pathname === "/api/auth/google" && m === "POST") {
        const { credential } = await request.json();
        const googleRes = await fetch(`https://oauth2.googleapis.com/tokeninfo?id_token=${credential}`);
        if (!googleRes.ok) return new Response(JSON.stringify({ error: "Token Google tidak valid." }), { status: 401, headers });
        const googleData = await googleRes.json();
        const email = googleData.email;
        let users = await env.DB.get("business_users", { type: "json" }) || {};
        if (!users[email]) {
            const token = crypto.randomUUID();
            const folderId = "FLD-" + Math.random().toString(36).substr(2, 8).toUpperCase();
            users[email] = { token, folderId, type: "google", pass: null, avatar: googleData.picture || "" };
            await env.DB.put("business_users", JSON.stringify(users));
            await env.DB.put(`workspace_${folderId}`, JSON.stringify({ posts: [], files: [] }));
        }
        const user = users[email];
        return new Response(JSON.stringify({ success: true, token: user.token, user: { email, folderId: user.folderId, avatar: user.avatar || "" }, needsPassword: user.pass === null }), { headers });
      }

      if (url.pathname === "/api/auth/set-password" && m === "POST") {
          const { email, token, newPass } = await request.json();
          let users = await env.DB.get("business_users", { type: "json" }) || {};
          if (!users[email] || users[email].token !== token) return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers });
          users[email].pass = newPass;
          await env.DB.put("business_users", JSON.stringify(users));
          return new Response(JSON.stringify({ success: true }), { headers });
      }

      if (url.pathname === "/api/users/profile" && m === "POST") {
          const authHeader = request.headers.get("Authorization");
          const currentUser = await getUserFromToken(authHeader ? authHeader.replace("Bearer ", "") : null);
          if (!currentUser) return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers });
          const { avatarBase64 } = await request.json();
          let users = await env.DB.get("business_users", { type: "json" }) || {};
          users[currentUser.email].avatar = avatarBase64;
          await env.DB.put("business_users", JSON.stringify(users));
          return new Response(JSON.stringify({ success: true, avatar: avatarBase64 }), { headers });
      }

      if (url.pathname === "/api/users/search" && m === "GET") {
          const authHeader = request.headers.get("Authorization");
          const currentUser = await getUserFromToken(authHeader ? authHeader.replace("Bearer ", "") : null);
          if (!currentUser) return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers });
          const q = url.searchParams.get("q").toLowerCase();
          let users = await env.DB.get("business_users", { type: "json" }) || {};
          let results = [];
          for(let email in users) {
              if(email.toLowerCase().includes(q) && email !== currentUser.email) {
                  results.push({ email: email, avatar: users[email].avatar || "" });
              }
          }
          return new Response(JSON.stringify(results), { headers });
      }

      if (url.pathname === "/api/dm" && (m === "GET" || m === "POST")) {
          const authHeader = request.headers.get("Authorization");
          const currentUser = await getUserFromToken(authHeader ? authHeader.replace("Bearer ", "") : null);
          if (!currentUser) return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers });
          
          if (m === "POST") {
              const { target, text } = await request.json();
              const pairId = [currentUser.email, target].sort().join("_"); 
              let chat = await env.DB.get(`dm_${pairId}`, { type: "json" }) || []; 
              const timeStr = new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" });
              chat.push({ from: currentUser.email, text, time: timeStr });
              if (chat.length > 50) chat.shift();
              await env.DB.put(`dm_${pairId}`, JSON.stringify(chat));

              let inboxState = await env.DB.get(`inbox_${target}`, { type: "json" }) || {};
              if(!inboxState[currentUser.email]) inboxState[currentUser.email] = { unread: 0, lastMessage: text, time: timeStr };
              inboxState[currentUser.email].unread += 1;
              inboxState[currentUser.email].lastMessage = text;
              inboxState[currentUser.email].time = timeStr;
              await env.DB.put(`inbox_${target}`, JSON.stringify(inboxState));

              let senderInbox = await env.DB.get(`inbox_${currentUser.email}`, { type: "json" }) || {};
              if(!senderInbox[target]) senderInbox[target] = { unread: 0, lastMessage: text, time: timeStr };
              else {
                  senderInbox[target].lastMessage = text;
                  senderInbox[target].time = timeStr;
              }
              await env.DB.put(`inbox_${currentUser.email}`, JSON.stringify(senderInbox));

              return new Response(JSON.stringify({ success: true, chat }), { headers });
          }
          if (m === "GET") {
              const target = url.searchParams.get("target");
              const pairId = [currentUser.email, target].sort().join("_");
              let chat = await env.DB.get(`dm_${pairId}`, { type: "json" }) || [];
              
              let inboxState = await env.DB.get(`inbox_${currentUser.email}`, { type: "json" }) || {};
              if(inboxState[target]) {
                  inboxState[target].unread = 0;
                  await env.DB.put(`inbox_${currentUser.email}`, JSON.stringify(inboxState));
              }

              return new Response(JSON.stringify(chat), { headers });
          }
      }

      if (url.pathname === "/api/dm/threads" && m === "GET") {
          const authHeader = request.headers.get("Authorization");
          const currentUser = await getUserFromToken(authHeader ? authHeader.replace("Bearer ", "") : null);
          if (!currentUser) return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers });
          
          let inboxState = await env.DB.get(`inbox_${currentUser.email}`, { type: "json" }) || {};
          let threads = [];
          for(let partner in inboxState) {
              threads.push({
                  partner: partner,
                  lastMessage: inboxState[partner].lastMessage,
                  time: inboxState[partner].time,
                  unreadCount: inboxState[partner].unread || 0
              });
          }
          threads.sort((a, b) => new Date(b.time) - new Date(a.time));
          return new Response(JSON.stringify({ threads }), { headers });
      }

      // ======================================================================
      // FITUR AI CHAT (MENGGUNAKAN GROQ API - LEBIH MUDAH & STABIL)
      // Dapatkan API Key gratis di: https://console.groq.com
      // ======================================================================
      if (url.pathname === "/api/ai-chat" && m === "POST") {
          const { message } = await request.json();
          
          // GANTI DENGAN GROQ API KEY ANDA (Format: gsk_...)
          const GROQ_API_KEY = "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"; 

          try {
              const groqRes = await fetch("https://api.groq.com/openai/v1/chat/completions", {
                  method: "POST",
                  headers: {
                      "Content-Type": "application/json",
                      "Authorization": `Bearer ${GROQ_API_KEY}`
                  },
                  body: JSON.stringify({
                      model: "llama-3.3-70b-versatile",
                      messages: [{ role: "user", content: message }]
                  })
              });

              const groqData = await groqRes.json();

              if (!groqRes.ok) {
                  throw new Error(groqData.error?.message || "Gagal menghubungi server Groq AI.");
              }

              const reply = groqData.choices[0].message.content;
              return new Response(JSON.stringify({ reply }), { headers });

          } catch (err) {
              return new Response(JSON.stringify({ reply: "Sistem Error: " + err.message }), { headers });
          }
      }

      if (url.pathname.includes("/api/workspace/")) {
          const authHeader = request.headers.get("Authorization");
          const currentUser = await getUserFromToken(authHeader ? authHeader.replace("Bearer ", "") : null);
          if (!currentUser) return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers });
          let wsData = await env.DB.get(`workspace_${currentUser.folderId}`, { type: "json" }) || { posts: [], files: [] };
          const timeNow = new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" });
          if (m === "GET") return new Response(JSON.stringify(wsData), { headers });
          if (m === "POST" && url.pathname.includes("/api/workspace/status")) {
              const { text } = await request.json();
              wsData.posts.unshift({ id: Date.now(), text, time: timeNow });
              if (wsData.posts.length > 20) wsData.posts.pop();
              await env.DB.put(`workspace_${currentUser.folderId}`, JSON.stringify(wsData));
              return new Response(JSON.stringify({ success: true, data: wsData }), { headers });
          }          
          if (m === "POST" && url.pathname.includes("/api/workspace/file")) {
              const { fileBase64, fileType, fileName, title, description } = await request.json();
              wsData.files.unshift({ id: Date.now(), data: fileBase64, type: fileType, name: fileName, title: title || fileName, description: description || "", time: timeNow });
              if (wsData.files.length > 10) wsData.files.pop();
              await env.DB.put(`workspace_${currentUser.folderId}`, JSON.stringify(wsData));
              return new Response(JSON.stringify({ success: true, data: wsData }), { headers });
          }          
          if ((m === "PUT" || m === "DELETE") && url.pathname.includes("/api/workspace/item")) {
              const { itemType, id, text, title, description } = await request.json();
              const targetId = Number(id); 
              if (m === "DELETE") {
                  if (itemType === "post") wsData.posts = wsData.posts.filter(p => p.id !== targetId);
                  if (itemType === "file") wsData.files = wsData.files.filter(f => f.id !== targetId);
              }
              if (m === "PUT") {
                  if (itemType === "post") {
                      let idx = wsData.posts.findIndex(p => p.id === targetId);
                      if (idx !== -1) wsData.posts[idx].text = text;
                  }
                  if (itemType === "file") {
                      let idx = wsData.files.findIndex(f => f.id === targetId);
                      if (idx !== -1) {
                          wsData.files[idx].title = title;
                          wsData.files[idx].description = description;
                      }
                  }
              }
              await env.DB.put(`workspace_${currentUser.folderId}`, JSON.stringify(wsData));
              return new Response(JSON.stringify({ success: true, data: wsData }), { headers });
          }
      }

      if (url.pathname.includes("/api/liveloc")) {
          if (m === "POST") {
              const { lat, lng } = await request.json();
              await env.DB.put("admin_live_loc_termux", JSON.stringify({ lat, lng, time: new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" }) }));
              return new Response(JSON.stringify({ success: true }), { headers });
          }
          if (m === "GET") {
              const loc = await env.DB.get("admin_live_loc_termux", { type: "json" }) || { lat: null, lng: null, time: "Offline" };
              return new Response(JSON.stringify(loc), { headers });
          }
      }

      if (url.pathname.includes("/api/sns-pro") && m === "POST") {
          const { target, mode } = await request.json();
          const RAPIDAPI_KEY = "e8c898177cmsh6c7eecbdf063589p1471d9jsn18f583909483";
          const RAPIDAPI_HOST = "instagram-looter2.p.rapidapi.com";
          let API_ENDPOINT_URL = `https://${RAPIDAPI_HOST}/search?query=${encodeURIComponent(target)}`;
          if (mode === "profile") {
              API_ENDPOINT_URL = `https://${RAPIDAPI_HOST}/profile?username=${encodeURIComponent(target)}`;
          }
          try {
              const fetchRes = await fetch(API_ENDPOINT_URL, { 
                  headers: { 
                      "x-rapidapi-key": RAPIDAPI_KEY, 
                      "x-rapidapi-host": RAPIDAPI_HOST,
                      "Content-Type": "application/json"
                  } 
              });
              if (!fetchRes.ok) {
                  const fallbackRes = await fetch(`https://${RAPIDAPI_HOST}/search?query=${encodeURIComponent(target)}`, { 
                      headers: { "x-rapidapi-key": RAPIDAPI_KEY, "x-rapidapi-host": RAPIDAPI_HOST, "Content-Type": "application/json" } 
                  });
                  const apiData = await fallbackRes.json();
                  return new Response(JSON.stringify({ success: true, data: apiData }), { headers });
              }
              const apiData = await fetchRes.json();
              return new Response(JSON.stringify({ success: true, data: apiData }), { headers });
          } catch(e) {
              return new Response(JSON.stringify({ success: false, error: "OFFLINE" + e.message }), { headers });
          }
      }

      if (url.pathname === "/api/admin/login" && m === "POST") {
          const { pass } = await request.json();
          if (pass === "ezraelvi21#") { 
              return new Response(JSON.stringify({ success: true, token: "MASTER-" + crypto.randomUUID() }), { headers });
          }
          return new Response(JSON.stringify({ error: "Password Salah" }), { status: 401, headers });
      }

      if (url.pathname === "/api/admin/users" && m === "GET") {
          if (!request.headers.get("Authorization")?.startsWith("MASTER-")) return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers });
          const users = await env.DB.get("business_users", { type: "json" }) || {};
          return new Response(JSON.stringify(users), { headers });
      }

      if (url.pathname === "/api/admin/spy" && m === "POST") {
          if (!request.headers.get("Authorization")?.startsWith("MASTER-")) return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers });
          const { folderId } = await request.json();
          const wsData = await env.DB.get(`workspace_${folderId}`, { type: "json" }) || { posts: [], files: [] };
          return new Response(JSON.stringify(wsData), { headers });
      }

      if (url.pathname === "/api/admin/delete" && m === "POST") {
          if (!request.headers.get("Authorization")?.startsWith("MASTER-")) return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers });
          const { email, folderId } = await request.json();
          let users = await env.DB.get("business_users", { type: "json" }) || {};
          delete users[email];
          await env.DB.put("business_users", JSON.stringify(users)); 
          await env.DB.delete(`workspace_${folderId}`);
          return new Response(JSON.stringify({ success: true }), { headers });
      }
      return new Response(JSON.stringify({ error: "Eror" + url.pathname }), { status: 404, headers });
    } catch (x) {
      return new Response(JSON.stringify({ error: "Server Error: " + x.message }), { status: 500, headers });
    }}};